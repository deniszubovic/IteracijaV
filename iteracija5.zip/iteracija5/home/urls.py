# in yourappname/urls.py
from django.urls import path
from .views import home, index

app_name = 'home'

urlpatterns = [
    path('', home, name='home'),
    # Add other URL patterns as needed
]
