from django.shortcuts import render

def home(request):
    return render(request, 'home/home.html')

def index(request):
    # Your view logic goes here
    return render(request, 'home/index.html')