from rest_framework import serializers
from .models import Kupac


class KupacSerializer(serializers.ModelSerializer):
    class Meta:
        model = Kupac
        fields = '__all__'
