# kupci/models.py

from django.db import models

class Kupac(models.Model):
    ime = models.CharField(max_length=100)
    ulica_i_broj = models.CharField(max_length=100)
    ptt_broj = models.CharField(max_length=5)
    mjesto = models.CharField(max_length=50)
    drzava = models.IntegerField()
    telefon = models.CharField(max_length=50)

    class Meta:
        db_table = 'kupci'


