from django.urls import path
from .views import KupacListCreateView, KupacDetailView

urlpatterns = [
    path('api/kupci/', KupacListCreateView.as_view(), name='kupci-list-create'),
    path('api/kupci/<int:pk>/', KupacDetailView.as_view(), name='kupci-detail'),
    # Add other URL patterns as needed
]
