from rest_framework import generics
from .models import Kupac
from .serializers import KupacSerializer


class KupacListCreateView(generics.ListCreateAPIView):
    queryset = Kupac.objects.all()
    serializer_class = KupacSerializer


class KupacDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Kupac.objects.all()
    serializer_class = KupacSerializer
