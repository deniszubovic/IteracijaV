# proizvodi/urls.py
from django.urls import path
from .views import proizvodi_list

app_name = 'proizvodi'

urlpatterns = [
    path('', proizvodi_list, name='proizvodi_list'),
]
