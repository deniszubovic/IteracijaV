from django.apps import AppConfig


class ProizvodiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'proizvodi'
