# proizvodi/views.py
from django.shortcuts import render
from .models import Proizvod, Slika
from PIL import Image
from io import BytesIO
import base64

def proizvodi_list(request):
    proizvodi = Proizvod.objects.all()

    for proizvod in proizvodi:
        proizvod.slike = []
        #proizvod.slike = Slika.objects.filter(fk_proizvod=proizvod.id).all()
        for slika in Slika.objects.filter(fk_proizvod=proizvod.id).all():
            img = Image.open(BytesIO(slika.slika))
            # Convert the image to RGB mode if it's in RGBA mode
            if img.mode == 'RGBA':
                img = img.convert('RGB')
            # Resize the image

            new_height = int((120 / float(img.size[0])) * img.size[1])

            img = img.resize((120, new_height))

            # Save the resized image to BytesIO
            buffer = BytesIO()
            img.save(buffer, format='JPEG')
            slika.resized_image = buffer.getvalue()

            proizvod.slike.append(slika)

    return render(request, 'proizvodi/proizvodi_list.html', {'proizvodi': proizvodi})
