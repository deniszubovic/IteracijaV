# proizvodi/models.py
from django.db import models

class Proizvod(models.Model):
    naziv = models.CharField(max_length=255)
    kategorija = models.CharField(max_length=100)
    opis = models.TextField()
    cijena = models.DecimalField(max_digits=10, decimal_places=2)
    class Meta:
        db_table = 'proizvodi'


class Slika(models.Model):
    fk_proizvod = models.ForeignKey(Proizvod, on_delete=models.CASCADE, db_column='id_proizvod')
    slika = models.ImageField(upload_to='proizvodi_slike/')
    default_slika = models.IntegerField(default=1)
    class Meta:
        db_table = 'slike'
