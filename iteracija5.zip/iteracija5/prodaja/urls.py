from django.urls import path
from . import views

app_name = 'prodaja'

urlpatterns = [
    path('', views.prodaja_page, name='prodaja_page'),
]