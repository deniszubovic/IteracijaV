# prodaja/views.py

from django.shortcuts import render
from django.db import connection

def prodaja_page(request):
    if request.method == 'GET':
        # Get the dates from the form
        datumod = request.GET.get('datumod')
        datumdo = request.GET.get('datumdo')

        # Assuming you have a MySQL procedure named 'get_sales_data'
        with connection.cursor() as cursor:
            cursor.callproc('ProdajaPoKupcimaZaPeriod', [datumod, datumdo])
            results = cursor.fetchall()

        # Pass the results to the template
        context = {'results': results}
        return render(request, 'prodaja/prodaja.html', context)

    return render(request, 'prodaja/prodaja.html')
