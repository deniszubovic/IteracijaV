from django.urls import path
from .views import NarudzbaView

urlpatterns = [
    path('api/narudzba/', NarudzbaView.as_view(), name='narudzba-api')
]
