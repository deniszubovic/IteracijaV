from django.db import models


class Narudzba(models.Model):
    id = models.IntegerField()

