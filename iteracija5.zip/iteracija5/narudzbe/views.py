from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db import connection


class NarudzbaView(APIView):
    def get(self, request, *args, **kwargs):
        id = request.query_params.get('id')

        if id is None:
            return Response({'error': 'id narudzbe nije proslijedjen'}, status=status.HTTP_400_BAD_REQUEST)

        with connection.cursor() as cursor:
            cursor.callproc('StatusNarudzbe', [id])
            results = cursor.fetchall()

        return Response({'data': results})
